"""Fallback magic_denoise for run_11 gen 2 — knn=12, t=3, n_pca=100."""

import numpy as np
import scprep
from magic import MAGIC


def magic_denoise(X, **kwargs):
    X_arr = scprep.utils.toarray(X).astype(np.float64)
    X_t = scprep.utils.matrix_transform(X_arr, np.sqrt)
    X_n, libsize = scprep.normalize.library_size_normalize(
        X_t, rescale=1, return_library_size=True
    )
    Y = MAGIC(
        knn=12, t=3, n_pca=100, decay=1,
        solver="approximate", verbose=False, random_state=12,
    ).fit_transform(X_n, genes="all_genes")
    Y = scprep.utils.matrix_transform(Y, np.square)
    Y = scprep.utils.matrix_vector_elementwise_multiply(Y, libsize, axis=0)
    return np.maximum(np.asarray(Y), 0)
