import numpy as np
import graphtools
import scprep

def magic_denoise(X, knn=15, t=3, n_pca=50, solver="approximate",
                  decay=0.8, knn_max=None, random_state=None, n_jobs=1, **kwargs):
    """Denoise scRNA‑seq counts using MAGIC.

    Parameters are tuned for the pancreas benchmark.
    """
    if knn_max is None:
        knn_max = knn * 3

    # Ensure dense array, float64
    X_work = scprep.utils.toarray(X).astype(np.float64)
    # Variance‑stabilising sqrt transform
    X_work = np.sqrt(X_work)
    # Library‑size normalisation (per cell) – keep scaling factor to revert later
    X_work, libsize = scprep.normalize.library_size_normalize(
        X_work, rescale=1, return_library_size=True
    )

    # Build the affinity graph
    graph = graphtools.Graph(
        X_work,
        n_pca=n_pca if X_work.shape[1] > n_pca else None,
        knn=knn,
        knn_max=knn_max,
        decay=decay,
        thresh=1e-4,
        random_state=random_state,
        n_jobs=n_jobs,
        verbose=0,
    )
    diff_op = graph.diff_op

    # Choose data representation (approximate is faster and works well)
    data = graph.data_nu if solver == "approximate" else scprep.utils.to_array_or_spmatrix(graph.data)
    data_imputed = scprep.utils.toarray(data)

    # Diffusion – t steps (matrix power is efficient for small t)
    if t > 0 and diff_op.shape[1] < data_imputed.shape[1]:
        diff_op_t = np.linalg.matrix_power(scprep.utils.toarray(diff_op), t)
        data_imputed = diff_op_t.dot(data_imputed)
    else:
        for _ in range(t):
            data_imputed = diff_op.dot(data_imputed)

    # If using approximate solver, map back to original space
    if solver == "approximate":
        data_imputed = graph.inverse_transform(data_imputed, columns=None)

    # Inverse of sqrt transform
    data_imputed = np.square(data_imputed)
    # Re‑apply library size scaling per cell
    data_imputed = scprep.utils.matrix_vector_elementwise_multiply(
        data_imputed, libsize, axis=0
    )
    # Ensure non‑negative and finite
    np.clip(data_imputed, 0, None, out=data_imputed)
    data_imputed[np.isinf(data_imputed)] = 0
    return data_imputed
