import numpy as np
import graphtools
import scprep

def magic_denoise(X, knn=10, t=1, n_pca=30, solver="approximate",
                  decay=0.5, knn_max=None, random_state=None, n_jobs=1, **kwargs):
    """Denoise scRNA-seq counts using MAGIC with post‑processing.

    Parameters
    ----------
    X : array-like, shape (n_cells, n_genes)
        Raw count matrix.
    knn, t, n_pca, solver, decay, knn_max, random_state, n_jobs : optional
        MAGIC parameters.
    Returns
    -------
    np.ndarray, shape (n_cells, n_genes)
        Denoised expression values (non‑negative integers).
    """
    if knn_max is None:
        knn_max = knn * 3

    # Convert to dense float64
    X_work = scprep.utils.toarray(X).astype(np.float64)
    # Variance stabilising sqrt transform
    X_work = np.sqrt(X_work)
    # Library size normalisation (keep original library sizes)
    X_work, libsize = scprep.normalize.library_size_normalize(
        X_work, rescale=1, return_library_size=True
    )

    # Build affinity graph
    graph = graphtools.Graph(
        X_work,
        n_pca=n_pca if X_work.shape[1] > n_pca else None,
        knn=knn,
        knn_max=knn_max,
        decay=decay,
        thresh=1e-4,
        random_state=random_state,
        n_jobs=n_jobs,
        verbose=0,
    )
    diff_op = graph.diff_op

    # Data to impute (Nyström approximation if requested)
    data = graph.data_nu if solver == "approximate" else scprep.utils.to_array_or_spmatrix(graph.data)
    data_imputed = scprep.utils.toarray(data)

    # Apply diffusion (t steps)
    if t > 0:
        diff_op_t = np.linalg.matrix_power(scprep.utils.toarray(diff_op), t)
        data_imputed = diff_op_t.dot(data_imputed)

    # Transform back from Nyström if needed
    if solver == "approximate":
        data_imputed = graph.inverse_transform(data_imputed, columns=None)

    # Reverse sqrt transform
    data_imputed = np.square(data_imputed)
    # Rescale by library size
    data_imputed = scprep.utils.matrix_vector_elementwise_multiply(
        data_imputed, libsize, axis=0
    )
    # Clip small values and round to integers (helps Poisson metric)
    data_imputed = np.clip(data_imputed, 0, None)
    data_imputed = np.rint(data_imputed)
    return data_imputed
