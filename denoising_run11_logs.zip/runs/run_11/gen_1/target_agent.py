#!/usr/bin/env python3
"""
Target agent for executing a single-task benchmark.

Accepts two command‑line arguments:
  --dataset_dir : absolute path to the read‑only dataset directory
  --working_dir : absolute path to the write‑only working directory

The agent:
  • Reads the task description from <dataset_dir>/task.md
  • Sends a prompt to the OSS Harmony LLM (model taken from TASK_MODEL env var)
  • Uses the provided tools (bash, read_file, write_file) to write code,
    run it, and evaluate results
  • Records the complete turn‑by‑turn trajectory
  • Saves the trajectory to <working_dir>/agent_execution.json
"""

# ── OSS Harmony agent loop (required — do not modify) ────────────────────────
import json, re, os, subprocess
from pathlib import Path

_MAX_TOOL_RESULT  = 1500
_MAX_CALLS_PER_TURN = 8

def _parse_harmony(content):
    analysis_match = re.search(r"^analysis(.*?)assistant", content, re.DOTALL)
    analysis = analysis_match.group(1).strip() if analysis_match else ""
    tool_calls = []
    for m in re.finditer(r"commentary to=functions\.(\w+)\s+json(\{.*?\})(?=assistant|$)", content, re.DOTALL):
        try:
            args = json.loads(m.group(2))
        except:
            args = {"raw": m.group(2)}
        tool_calls.append({"name": m.group(1), "args": args})
    final_match = re.search(r"final(.*?)$", content, re.DOTALL)
    return {
        "analysis": analysis,
        "tool_calls": tool_calls,
        "final": final_match.group(1).strip() if final_match else content.strip(),
    }

def _bash(cmd, timeout=120):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        out = r.stdout + (f"\n[stderr]\n{r.stderr}" if r.stderr else "")
        return out.strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return f"[ERROR] timed out after {timeout}s"
    except Exception as e:
        return f"[ERROR] {e}"

def _read_file(path):
    try:
        return Path(path).read_text(encoding="utf-8")
    except Exception as e:
        return f"[ERROR] {e}"

def _write_file(path, content):
    try:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(content, encoding="utf-8")
        return f"Written {len(content)} chars to {path}"
    except Exception as e:
        return f"[ERROR] {e}"

def _dispatch(name, args):
    if name == "bash":
        return _bash(args.get("command", ""))
    if name == "read_file":
        return _read_file(args.get("path", ""))
    if name == "write_file":
        return _write_file(args.get("path", ""), args.get("content", ""))
    return f"[ERROR] Unknown tool: {name}"

_TOOLS = [
    {"type":"function","function":{"name":"bash","description":"Run a bash command.","parameters":{"type":"object","properties":{"command":{"type":"string"}},"required":["command"]}}},
    {"type":"function","function":{"name":"read_file","description":"Read a file.","parameters":{"type":"object","properties":{"path":{"type":"string"}},"required":["path"]}}},
    {"type":"function","function":{"name":"write_file","description":"Write a file.","parameters":{"type":"object","properties":{"path":{"type":"string"},"content":{"type":"string"}},"required":["path","content"]}}},
]

def _run_oss_loop(model, task_prompt, working_dir, max_turns=15):
    from openai import OpenAI
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"], base_url=os.environ["OPENAI_BASE_URL"])
    model  = os.environ.get("TASK_MODEL", model)
    messages = [
        {"role":"system","content":"You are a concise ML engineer. Write Python scripts and run them with bash."},
        {"role":"user",  "content":task_prompt},
    ]
    trajectory = []
    for turn in range(1, max_turns + 1):
        try:
            resp = client.chat.completions.create(
                model=model,
                messages=messages,
                tools=_TOOLS,
                tool_choice="auto",
                max_tokens=4096,
            )
        except Exception as e:
            trajectory.append({"turn": turn, "error": str(e)})
            break

        parsed = _parse_harmony(resp.choices[0].message.content or "")
        calls  = parsed["tool_calls"][:_MAX_CALLS_PER_TURN]

        tool_results = ""
        for tc in calls:
            result = _dispatch(tc["name"], tc["args"])
            truncated = result[:_MAX_TOOL_RESULT] + ("…" if len(result) > _MAX_TOOL_RESULT else "")
            tool_results += f"\nTool: {tc['name']}\nResult:\n{truncated}\n"

        trajectory.append({
            "turn": turn,
            "analysis": parsed["analysis"],
            "tool_calls": calls,
            "final": parsed["final"],
        })

        if calls:
            summary = "; ".join(f"{tc['name']}({json.dumps(tc['args'])[:60]})" for tc in calls)
            messages.append({"role":"assistant","content":f"[Called: {summary}]"})
            messages.append({"role":"user","content":f"Actual results:{tool_results}\nContinue."})
        else:
            break
    return trajectory
# ─────────────────────────────────────────────────────────────────────────────

# ----------------------------------------------------------------------
# Main driver for the target agent
# ----------------------------------------------------------------------
import argparse
import json
import os
from pathlib import Path

def build_task_prompt(task_md: str, dataset_dir: str, working_dir: str) -> str:
    """
    Construct the prompt that will be sent to the LLM.
    It includes the raw task description and explicit instructions about
    where the dataset and working directories are, and the read/write policy.
    """
    prompt = f"""{task_md}

---

## Your Instructions

- **Dataset directory (READ‑ONLY)**: `{dataset_dir}`
- **Working directory (WRITE‑ONLY)**: `{working_dir}`
- You may only read files that reside under the dataset directory.
- You may only write files to locations under the working directory.

Use the provided tools (`bash`, `read_file`, `write_file`) to implement the required solution,
run any needed commands, and evaluate the result.  Iterate as needed to improve performance.

When you are satisfied, end the conversation (i.e., provide no tool calls in the final turn)."""
    return prompt

def main():
    parser = argparse.ArgumentParser(description="Target agent for a single‑task benchmark.")
    parser.add_argument("--dataset_dir", required=True, help="Absolute path to the read‑only dataset directory")
    parser.add_argument("--working_dir", required=True, help="Absolute path to the write‑only working directory")
    args = parser.parse_args()

    dataset_dir = os.path.abspath(args.dataset_dir)
    working_dir = os.path.abspath(args.working_dir)

    # Ensure working directory exists and is writable
    os.makedirs(working_dir, exist_ok=True)

    # Load the task description
    task_md_path = Path(dataset_dir, "task.md")
    if not task_md_path.is_file():
        raise FileNotFoundError(f"task.md not found in dataset directory: {dataset_dir}")

    task_md = task_md_path.read_text(encoding="utf-8")

    # Build the full prompt for the LLM
    task_prompt = build_task_prompt(task_md, dataset_dir, working_dir)

    # Run the OSS Harmony loop
    trajectory = _run_oss_loop("openai/gpt-oss-120b", task_prompt, working_dir)

    # Determine logging format (single‑execution assumed here)
    log_path = Path(working_dir, "agent_execution.json")
    with log_path.open("w", encoding="utf-8") as f:
        json.dump(trajectory, f, indent=2, ensure_ascii=False)

    print(f"Trajectory saved to: {log_path}")

if __name__ == "__main__":
    main()