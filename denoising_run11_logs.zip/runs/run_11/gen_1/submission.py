import numpy as np
import graphtools
import scprep

def magic_denoise(X, knn=5, t=3, n_pca=100, solver="exact",
                 decay=1, knn_max=None, random_state=None, n_jobs=1, **kwargs):
    """Exact MAGIC implementation for denoising scRNA‑seq counts.
    Returns a non‑negative dense array of the same shape as X.
    """
    X_arr = scprep.utils.toarray(X).astype(np.float64)
    # variance stabilising sqrt
    X_arr = np.sqrt(X_arr)
    # library size normalisation (returns scaling factors)
    X_arr, libsize = scprep.normalize.library_size_normalize(
        X_arr, rescale=1, return_library_size=True
    )
    if knn_max is None:
        knn_max = knn * 3
    graph = graphtools.Graph(
        X_arr,
        n_pca=n_pca if X_arr.shape[1] > n_pca else None,
        knn=knn,
        knn_max=knn_max,
        decay=decay,
        thresh=1e-4,
        random_state=random_state,
        n_jobs=n_jobs,
        verbose=0,
    )
    diff_op = graph.diff_op
    data = graph.data  # exact data matrix
    data_imputed = scprep.utils.toarray(data)
    # diffusion up to t steps (matrix power for speed when possible)
    if t > 0 and diff_op.shape[1] < data_imputed.shape[1]:
        diff_op_t = np.linalg.matrix_power(scprep.utils.toarray(diff_op), t)
        data_imputed = diff_op_t.dot(data_imputed)
    else:
        for _ in range(t):
            data_imputed = diff_op.dot(data_imputed)
    # inverse sqrt transform
    data_imputed = np.square(data_imputed)
    # rescale to original library sizes
    data_imputed = scprep.utils.matrix_vector_elementwise_multiply(
        data_imputed, libsize, axis=0
    )
    # ensure non‑negative finite values
    data_imputed = np.clip(data_imputed, 0, None)
    data_imputed = np.nan_to_num(data_imputed, nan=0.0, posinf=0.0, neginf=0.0)
    return data_imputed
