import numpy as np
import graphtools
import scprep

def magic_denoise(X, knn=15, t=2, n_pca=20, solver="approximate",
                  decay=1, knn_max=None, random_state=None, n_jobs=1, **kwargs):
    """Fast MAGIC‑style denoising tuned for the pancreas benchmark."""
    if knn_max is None:
        knn_max = knn * 3
    X_arr = scprep.utils.toarray(X).astype(np.float64)
    X_arr = np.sqrt(X_arr)
    X_arr, libsize = scprep.normalize.library_size_normalize(
        X_arr, rescale=1, return_library_size=True
    )
    graph = graphtools.Graph(
        X_arr,
        n_pca=n_pca if X_arr.shape[1] > n_pca else None,
        knn=knn,
        knn_max=knn_max,
        decay=decay,
        thresh=1e-4,
        random_state=random_state,
        n_jobs=n_jobs,
        verbose=0,
    )
    diff_op = graph.diff_op
    data = graph.data_nu if solver == "approximate" else scprep.utils.to_array_or_spmatrix(graph.data)
    imputed = scprep.utils.toarray(data)
    # diffusion
    for _ in range(t):
        imputed = diff_op.dot(imputed)
    if solver == "approximate":
        imputed = graph.inverse_transform(imputed, columns=None)
    imputed = np.square(imputed)
    imputed = scprep.utils.matrix_vector_elementwise_multiply(imputed, libsize, axis=0)
    imputed = np.clip(imputed, 0, np.finfo(imputed.dtype).max)
    return imputed
